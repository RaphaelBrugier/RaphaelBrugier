package com.rbrugier.wp.client.login;

import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.HTMLPanel;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;

public class WpTags extends Composite {
	
	private static final String html =
	    "<div id=\"loginform\" name=\"loginform\" class=\"formulaire\" >" +
	      "<p id=\"username\" >" +
	        "<label>Username<br/>" +
	      "</p>" +
	      "<p id=\"password\">" +
	        "<label>Password<br/>" +
	      "</p>" +
	      "<p id=\"forgetmenot\" class=\"forgetmenot\">" +
	        "<label>Remember Me</label>" +
	      "</p>" +
	      "<p id=\"submit\" class=\"submit\">" +
	      "</p>" +
	    "</div>";
	
	HTMLPanel htmlPanel;

	public WpTags() {
		htmlPanel = new HTMLPanel(html);
		
		// The username field
	    TextBox user = new TextBox();
	    user.addStyleName("input");
	    user.getElement().setId("user_login");
	    htmlPanel.add(user, "username");

	    // The password field
	    TextBox password = new PasswordTextBox();
	    password.addStyleName("input");
	    password.getElement().setId("user_pass");
	    htmlPanel.add(password, "password");

	    // The forget me not checkbox
	    CheckBox forgetMeNot = new CheckBox();
	    forgetMeNot.getElement().setId("rememberme");
	    htmlPanel.add(forgetMeNot, "forgetmenot");

	    // The log in button
	    Button submit = new Button("Log In");
	    submit.getElement().setId("wp-submit");
	    htmlPanel.add(submit, "submit");
		
		initWidget(htmlPanel);
	}

}
