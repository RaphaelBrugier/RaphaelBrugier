package com.rbrugier.wp.client;

import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.user.client.ui.RootLayoutPanel;
import com.rbrugier.wp.client.login.WpForm;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class WpLogin implements EntryPoint {
	/**

	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		WpForm wpForm = new WpForm();
		
		RootLayoutPanel.get().add(wpForm);
	}
}
